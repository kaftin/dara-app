const jwt = require('jsonwebtoken');
const { SECRET } = require('./auth');
const { validateMessageText } = require('./validate');
const { areFriends, isGroupMember, notify } = require('./helpers');

// Simple in-memory per-connection throttle: at most 15 messages per 10 seconds.
// Good enough to blunt a spam burst on a single-instance deployment; a
// multi-instance deployment behind a load balancer would want this tracked
// in something shared (e.g. Redis) instead, same as the Socket.io adapter
// note in the README.
const MSG_WINDOW_MS = 10 * 1000;
const MSG_MAX_PER_WINDOW = 15;

function withinRateLimit(socket) {
  const now = Date.now();
  socket.msgTimestamps = (socket.msgTimestamps || []).filter((t) => now - t < MSG_WINDOW_MS);
  if (socket.msgTimestamps.length >= MSG_MAX_PER_WINDOW) return false;
  socket.msgTimestamps.push(now);
  return true;
}

module.exports = function setupSockets(io, pool) {
  io.use((socket, next) => {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) return next(new Error('Missing token'));
    try {
      socket.user = jwt.verify(token, SECRET);
      next();
    } catch (e) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', async (socket) => {
    socket.join('user:' + socket.user.id);
    socket.msgTimestamps = [];

    // Join a room per group this user belongs to, so group_message broadcasts
    // reach them without a per-message membership lookup on every emit.
    try {
      const groups = await pool.query('SELECT group_id FROM group_members WHERE user_id = $1', [socket.user.id]);
      groups.rows.forEach((row) => socket.join('group:' + row.group_id));
    } catch (e) {
      console.error('[dara] Failed to join group rooms on connect:', e);
    }

    socket.on('private_message', async (payload) => {
      try {
        const toUserId = parseInt(payload && payload.toUserId, 10);
        const rawText = payload && payload.text;

        if (!Number.isInteger(toUserId)) return;
        const textError = validateMessageText(rawText);
        if (textError) { socket.emit('message_error', { error: textError }); return; }
        const text = rawText.trim();

        if (!(await areFriends(pool, socket.user.id, toUserId))) {
          socket.emit('message_error', { error: 'You can only message accepted friends' });
          return;
        }
        if (!withinRateLimit(socket)) {
          socket.emit('message_error', { error: "You're sending messages too fast. Slow down a little." });
          return;
        }

        const insert = await pool.query(
          'INSERT INTO messages (sender_id, recipient_id, text) VALUES ($1, $2, $3) RETURNING id, created_at AS "createdAt"',
          [socket.user.id, toUserId, text]
        );
        const msg = {
          id: insert.rows[0].id,
          senderId: socket.user.id,
          recipientId: toUserId,
          text,
          createdAt: insert.rows[0].createdAt
        };
        io.to('user:' + toUserId).emit('new_message', msg);
        io.to('user:' + socket.user.id).emit('new_message', msg);

        await notify(pool, io, toUserId, 'message', {
          fromUserId: socket.user.id,
          fromUsername: socket.user.username,
          preview: text.slice(0, 80)
        });
      } catch (e) {
        console.error('[dara] private_message error:', e);
        socket.emit('message_error', { error: 'Message could not be sent' });
      }
    });

    socket.on('group_message', async (payload) => {
      try {
        const groupId = parseInt(payload && payload.groupId, 10);
        const rawText = payload && payload.text;

        if (!Number.isInteger(groupId)) return;
        const textError = validateMessageText(rawText);
        if (textError) { socket.emit('message_error', { error: textError }); return; }
        const text = rawText.trim();

        if (!(await isGroupMember(pool, groupId, socket.user.id))) {
          socket.emit('message_error', { error: 'You are not a member of this group' });
          return;
        }
        if (!withinRateLimit(socket)) {
          socket.emit('message_error', { error: "You're sending messages too fast. Slow down a little." });
          return;
        }

        const insert = await pool.query(
          'INSERT INTO group_messages (group_id, sender_id, text) VALUES ($1, $2, $3) RETURNING id, created_at AS "createdAt"',
          [groupId, socket.user.id, text]
        );
        const msg = {
          id: insert.rows[0].id,
          groupId,
          senderId: socket.user.id,
          senderUsername: socket.user.username,
          text,
          createdAt: insert.rows[0].createdAt
        };
        io.to('group:' + groupId).emit('new_group_message', msg);

        const members = await pool.query('SELECT user_id FROM group_members WHERE group_id = $1 AND user_id != $2', [groupId, socket.user.id]);
        for (const row of members.rows) {
          await notify(pool, io, row.user_id, 'group_message', {
            groupId,
            fromUserId: socket.user.id,
            fromUsername: socket.user.username,
            preview: text.slice(0, 80)
          });
        }
      } catch (e) {
        console.error('[dara] group_message error:', e);
        socket.emit('message_error', { error: 'Message could not be sent' });
      }
    });
  });
};
