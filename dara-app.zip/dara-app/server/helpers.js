// Wrap async route handlers so a rejected promise reaches Express's error
// handling instead of crashing the process or hanging the request.
function ah(fn) {
  return (req, res, next) => fn(req, res, next).catch(next);
}

function publicUser(row) {
  return {
    id: row.id,
    username: row.username,
    avatarColor: row.avatar_color,
    rating: row.rating,
    wins: row.wins,
    losses: row.losses,
    aiGames: row.ai_games
  };
}

async function areFriends(pool, uidA, uidB) {
  const result = await pool.query(
    `SELECT 1 FROM friend_links
     WHERE status = 'accepted'
       AND ((requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1))`,
    [uidA, uidB]
  );
  return result.rows.length > 0;
}

async function isGroupMember(pool, groupId, userId) {
  const result = await pool.query(
    'SELECT 1 FROM group_members WHERE group_id = $1 AND user_id = $2',
    [groupId, userId]
  );
  return result.rows.length > 0;
}

// Creates a notification row and, if the recipient has a live socket
// connection, pushes it to them immediately over 'new_notification' so the
// client can update unread badges without polling. `io` is optional — pass
// null from anywhere that doesn't have access to it (the row still gets
// created and will show up next time the client fetches /api/notifications).
async function notify(pool, io, userId, type, data) {
  const result = await pool.query(
    'INSERT INTO notifications (user_id, type, data) VALUES ($1, $2, $3) RETURNING id, type, data, created_at AS "createdAt"',
    [userId, type, JSON.stringify(data || {})]
  );
  const row = result.rows[0];
  if (io) io.to('user:' + userId).emit('new_notification', row);
  return row;
}

module.exports = { ah, publicUser, areFriends, isGroupMember, notify };
