const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const http = require('http');
const { Server } = require('socket.io');

const { pool, init } = require('./db');
const setupSockets = require('./sockets');

const buildAuthRoutes = require('./routes/auth');
const buildProfileRoutes = require('./routes/profile');
const buildGameRoutes = require('./routes/game');
const buildFriendsRoutes = require('./routes/friends');
const buildMessagesRoutes = require('./routes/messages');
const buildNotificationRoutes = require('./routes/notifications');
const buildGroupsRoutes = require('./routes/groups');

// CORS_ORIGIN can be a comma-separated list of allowed origins for deployments
// where the client is hosted separately from this API. By default (unset) we
// reflect the request's own origin, which is what same-origin deployments
// (client served by this same process, as set up below) need.
const corsOptions = { origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true };

const app = express();

// Needed so express-rate-limit sees the real client IP when running behind a
// reverse proxy / load balancer (Render, Railway, etc. all put one in front).
app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", 'https://cdn.socket.io'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
      objectSrc: ["'none'"],
      baseUri: ["'self'"]
    }
  }
}));
app.use(cors(corsOptions));
app.use(express.json({ limit: '100kb' }));

// General API rate limit, plus a stricter one specifically on auth endpoints
// (registration/login) to slow down credential-stuffing and brute-force attempts.
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false });
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again in a few minutes.' }
});
app.use('/api/', apiLimiter);
app.use('/api/auth/', authLimiter);

const server = http.createServer(app);
const io = new Server(server, { cors: corsOptions });

// Serve the frontend from the sibling /client folder so the whole app is one process/one port.
app.use(express.static(path.join(__dirname, '..', 'client')));

// ---- Routes ----
const { router: profileRouter, getUserById } = buildProfileRoutes(pool);

app.use('/api/auth', buildAuthRoutes(pool));
app.use('/api', profileRouter); // exposes /api/me and /api/history
app.use('/api/game', buildGameRoutes(pool, getUserById));
app.use('/api/friends', buildFriendsRoutes(pool, io));
app.use('/api/messages', buildMessagesRoutes(pool));
app.use('/api/notifications', buildNotificationRoutes(pool));
app.use('/api/groups', buildGroupsRoutes(pool, io));

// Basic error handler for anything the route-level async wrapper (ah()) catches.
app.use((err, req, res, next) => {
  console.error('[dara] Unhandled error:', err);
  res.status(500).json({ error: 'Something went wrong on our end' });
});

setupSockets(io, pool);

const PORT = process.env.PORT || 3001;

init()
  .then(() => {
    server.listen(PORT, () => console.log('Dara server listening on port ' + PORT));
  })
  .catch((err) => {
    console.error('[dara] FATAL: could not initialize the database:', err);
    process.exit(1);
  });
