const express = require('express');
const { verifyToken } = require('../auth');
const { ah, areFriends, isGroupMember } = require('../helpers');

module.exports = function groupsRoutes(pool, io) {
  const router = express.Router();

  router.get('/', verifyToken, ah(async (req, res) => {
    const result = await pool.query(
      `SELECT g.id, g.name, g.created_by AS "createdBy",
              (SELECT json_agg(json_build_object('id', u.id, 'username', u.username))
               FROM group_members gm2 JOIN users u ON u.id = gm2.user_id WHERE gm2.group_id = g.id) AS members
       FROM groups_table g
       JOIN group_members gm ON gm.group_id = g.id
       WHERE gm.user_id = $1
       ORDER BY g.id DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  }));

  router.post('/', verifyToken, ah(async (req, res) => {
    const { name, memberIds } = req.body || {};
    const groupName = typeof name === 'string' ? name.trim() : '';
    if (!groupName || groupName.length > 40) return res.status(400).json({ error: 'Enter a group name (up to 40 characters)' });

    const ids = Array.isArray(memberIds) ? memberIds.map((i) => parseInt(i, 10)).filter(Number.isInteger) : [];
    if (!ids.length) return res.status(400).json({ error: 'Pick at least one friend to add' });

    // Every member being added must be an accepted friend of the creator —
    // you can't be looped into a group by someone who isn't actually your friend.
    for (const id of ids) {
      if (!(await areFriends(pool, req.user.id, id))) {
        return res.status(400).json({ error: 'You can only add accepted friends to a group' });
      }
    }

    const groupInsert = await pool.query(
      'INSERT INTO groups_table (name, created_by) VALUES ($1, $2) RETURNING id',
      [groupName, req.user.id]
    );
    const groupId = groupInsert.rows[0].id;

    const allMemberIds = [req.user.id, ...ids];
    for (const uid of allMemberIds) {
      await pool.query(
        'INSERT INTO group_members (group_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [groupId, uid]
      );
      if (io) {
        const sockets = await io.in('user:' + uid).fetchSockets();
        sockets.forEach((s) => s.join('group:' + groupId));
      }
    }

    res.json({ id: groupId, name: groupName });
  }));

  router.get('/:groupId/messages', verifyToken, ah(async (req, res) => {
    const gid = parseInt(req.params.groupId, 10);
    if (!Number.isInteger(gid)) return res.status(400).json({ error: 'Invalid group id' });
    if (!(await isGroupMember(pool, gid, req.user.id))) return res.status(403).json({ error: 'You are not a member of this group' });

    const result = await pool.query(
      `SELECT gm.id, gm.sender_id AS "senderId", u.username AS "senderUsername", gm.text, gm.created_at AS "createdAt"
       FROM group_messages gm JOIN users u ON u.id = gm.sender_id
       WHERE gm.group_id = $1 ORDER BY gm.id ASC LIMIT 200`,
      [gid]
    );
    res.json(result.rows);
  }));

  return router;
};
