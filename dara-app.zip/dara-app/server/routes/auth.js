const express = require('express');
const bcrypt = require('bcryptjs');
const { signToken } = require('../auth');
const { validateUsername, validatePassword } = require('../validate');
const { ah } = require('../helpers');

module.exports = function authRoutes(pool) {
  const router = express.Router();

  router.post('/register', ah(async (req, res) => {
    const { username, password } = req.body || {};
    const uname = typeof username === 'string' ? username.trim() : '';

    const usernameError = validateUsername(uname);
    if (usernameError) return res.status(400).json({ error: usernameError });
    const passwordError = validatePassword(password);
    if (passwordError) return res.status(400).json({ error: passwordError });

    const existing = await pool.query('SELECT id FROM users WHERE lower(username) = lower($1)', [uname]);
    if (existing.rows.length) return res.status(409).json({ error: 'That username is already taken' });

    const hash = bcrypt.hashSync(password, 12);
    const insert = await pool.query(
      'INSERT INTO users (username, password_hash) VALUES ($1, $2) RETURNING id, username',
      [uname, hash]
    );
    const user = insert.rows[0];
    res.json({ token: signToken(user), user });
  }));

  router.post('/login', ah(async (req, res) => {
    const { username, password } = req.body || {};
    const result = await pool.query('SELECT * FROM users WHERE lower(username) = lower($1)', [(username || '').trim()]);
    const row = result.rows[0];
    // Same generic error whether the username doesn't exist or the password is
    // wrong, so a caller can't use this endpoint to enumerate valid usernames.
    if (!row || !bcrypt.compareSync(password || '', row.password_hash)) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }
    res.json({ token: signToken(row), user: { id: row.id, username: row.username } });
  }));

  return router;
};
