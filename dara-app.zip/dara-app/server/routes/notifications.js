const express = require('express');
const { verifyToken } = require('../auth');
const { ah } = require('../helpers');

module.exports = function notificationRoutes(pool) {
  const router = express.Router();

  router.get('/', verifyToken, ah(async (req, res) => {
    const result = await pool.query(
      `SELECT id, type, data, is_read AS "isRead", created_at AS "createdAt"
       FROM notifications WHERE user_id = $1 ORDER BY id DESC LIMIT 50`,
      [req.user.id]
    );
    res.json(result.rows);
  }));

  router.post('/read', verifyToken, ah(async (req, res) => {
    const { ids } = req.body || {};
    if (Array.isArray(ids) && ids.length) {
      const cleanIds = ids.map((i) => parseInt(i, 10)).filter(Number.isInteger);
      if (cleanIds.length) {
        await pool.query(
          'UPDATE notifications SET is_read = true WHERE user_id = $1 AND id = ANY($2::int[])',
          [req.user.id, cleanIds]
        );
      }
    } else {
      await pool.query('UPDATE notifications SET is_read = true WHERE user_id = $1 AND is_read = false', [req.user.id]);
    }
    res.json({ ok: true });
  }));

  return router;
};
