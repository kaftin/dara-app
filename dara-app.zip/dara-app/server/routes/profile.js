const express = require('express');
const { verifyToken } = require('../auth');
const { validateAvatarColor } = require('../validate');
const { ah, publicUser } = require('../helpers');

module.exports = function profileRoutes(pool) {
  const router = express.Router();

  async function getUserById(id) {
    const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    return result.rows[0];
  }

  router.get('/me', verifyToken, ah(async (req, res) => {
    const row = await getUserById(req.user.id);
    if (!row) return res.status(404).json({ error: 'User not found' });
    res.json(publicUser(row));
  }));

  router.patch('/me', verifyToken, ah(async (req, res) => {
    const { avatarColor } = req.body || {};
    if (avatarColor !== undefined) {
      const colorError = validateAvatarColor(avatarColor);
      if (colorError) return res.status(400).json({ error: colorError });
      await pool.query('UPDATE users SET avatar_color = $1 WHERE id = $2', [avatarColor, req.user.id]);
    }
    const row = await getUserById(req.user.id);
    res.json(publicUser(row));
  }));

  router.get('/history', verifyToken, ah(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
    const result = await pool.query(
      `SELECT id, result, rating_after AS "ratingAfter", board_size AS "boardSize", created_at AS "createdAt"
       FROM game_history WHERE user_id = $1 ORDER BY id DESC LIMIT $2`,
      [req.user.id, limit]
    );
    res.json(result.rows);
  }));

  return { router, getUserById };
};
