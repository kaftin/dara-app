const express = require('express');
const { verifyToken } = require('../auth');
const { ah } = require('../helpers');

module.exports = function gameRoutes(pool, getUserById) {
  const router = express.Router();

  router.post('/result', verifyToken, ah(async (req, res) => {
    const { result, boardSize } = req.body || {}; // result: 'win' | 'loss'
    if (result !== 'win' && result !== 'loss') return res.status(400).json({ error: "result must be 'win' or 'loss'" });

    const row = await getUserById(req.user.id);
    if (!row) return res.status(404).json({ error: 'User not found' });

    let rating = row.rating, wins = row.wins, losses = row.losses;
    if (result === 'win') { rating += 25; wins += 1; }
    else { rating = Math.max(0, rating - 20); losses += 1; }

    await pool.query(
      'UPDATE users SET rating = $1, wins = $2, losses = $3, ai_games = ai_games + 1 WHERE id = $4',
      [rating, wins, losses, req.user.id]
    );
    await pool.query(
      'INSERT INTO game_history (user_id, result, rating_after, board_size) VALUES ($1, $2, $3, $4)',
      [req.user.id, result, rating, typeof boardSize === 'string' ? boardSize.slice(0, 16) : null]
    );

    res.json({ rating, wins, losses });
  }));

  return router;
};
