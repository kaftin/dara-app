const express = require('express');
const { verifyToken } = require('../auth');
const { ah, notify } = require('../helpers');

module.exports = function friendsRoutes(pool, io) {
  const router = express.Router();

  router.get('/', verifyToken, ah(async (req, res) => {
    const uid = req.user.id;

    const friends = await pool.query(
      `SELECT u.id, u.username, u.avatar_color AS "avatarColor", u.rating
       FROM friend_links f
       JOIN users u ON u.id = (CASE WHEN f.requester_id = $1 THEN f.addressee_id ELSE f.requester_id END)
       WHERE (f.requester_id = $1 OR f.addressee_id = $1) AND f.status = 'accepted'`,
      [uid]
    );

    const incomingRequests = await pool.query(
      `SELECT f.id AS "requestId", u.id AS "userId", u.username
       FROM friend_links f
       JOIN users u ON u.id = f.requester_id
       WHERE f.addressee_id = $1 AND f.status = 'pending'`,
      [uid]
    );

    const outgoingRequests = await pool.query(
      `SELECT f.id AS "requestId", u.id AS "userId", u.username
       FROM friend_links f
       JOIN users u ON u.id = f.addressee_id
       WHERE f.requester_id = $1 AND f.status = 'pending'`,
      [uid]
    );

    res.json({ friends: friends.rows, incomingRequests: incomingRequests.rows, outgoingRequests: outgoingRequests.rows });
  }));

  router.post('/request', verifyToken, ah(async (req, res) => {
    const { username } = req.body || {};
    const uname = typeof username === 'string' ? username.trim() : '';
    if (!uname || uname.length > 24) return res.status(400).json({ error: 'Enter a valid username' });

    const targetResult = await pool.query('SELECT id, username FROM users WHERE lower(username) = lower($1)', [uname]);
    const target = targetResult.rows[0];
    if (!target) return res.status(404).json({ error: 'No user with that username' });
    if (target.id === req.user.id) return res.status(400).json({ error: "You can't add yourself" });

    const already = await pool.query(
      `SELECT 1 FROM friend_links
       WHERE (requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1)`,
      [req.user.id, target.id]
    );
    if (already.rows.length) return res.status(409).json({ error: 'A request or friendship already exists' });

    await pool.query(
      "INSERT INTO friend_links (requester_id, addressee_id, status) VALUES ($1, $2, 'pending')",
      [req.user.id, target.id]
    );
    await notify(pool, io, target.id, 'friend_request', { fromUserId: req.user.id, fromUsername: req.user.username });
    res.json({ ok: true });
  }));

  router.post('/accept', verifyToken, ah(async (req, res) => {
    const requestId = parseInt(req.body && req.body.requestId, 10);
    if (!Number.isInteger(requestId)) return res.status(400).json({ error: 'Invalid request id' });

    const link = await pool.query('SELECT * FROM friend_links WHERE id = $1 AND addressee_id = $2', [requestId, req.user.id]);
    if (!link.rows.length) return res.status(404).json({ error: 'Request not found' });

    await pool.query("UPDATE friend_links SET status = 'accepted' WHERE id = $1", [requestId]);
    await notify(pool, io, link.rows[0].requester_id, 'friend_accept', { byUserId: req.user.id, byUsername: req.user.username });
    res.json({ ok: true });
  }));

  router.post('/decline', verifyToken, ah(async (req, res) => {
    const requestId = parseInt(req.body && req.body.requestId, 10);
    if (!Number.isInteger(requestId)) return res.status(400).json({ error: 'Invalid request id' });

    await pool.query('DELETE FROM friend_links WHERE id = $1 AND addressee_id = $2', [requestId, req.user.id]);
    res.json({ ok: true });
  }));

  router.delete('/:friendId', verifyToken, ah(async (req, res) => {
    const fid = parseInt(req.params.friendId, 10);
    if (!Number.isInteger(fid)) return res.status(400).json({ error: 'Invalid user id' });

    await pool.query(
      `DELETE FROM friend_links
       WHERE (requester_id = $1 AND addressee_id = $2) OR (requester_id = $2 AND addressee_id = $1)`,
      [req.user.id, fid]
    );
    res.json({ ok: true });
  }));

  return router;
};
