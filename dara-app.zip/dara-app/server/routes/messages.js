const express = require('express');
const { verifyToken } = require('../auth');
const { ah, areFriends } = require('../helpers');

module.exports = function messagesRoutes(pool) {
  const router = express.Router();

  router.get('/:friendId', verifyToken, ah(async (req, res) => {
    const fid = parseInt(req.params.friendId, 10);
    if (!Number.isInteger(fid)) return res.status(400).json({ error: 'Invalid user id' });
    if (!(await areFriends(pool, req.user.id, fid))) return res.status(403).json({ error: 'You can only view chats with accepted friends' });

    const result = await pool.query(
      `SELECT id, sender_id AS "senderId", recipient_id AS "recipientId", text, created_at AS "createdAt"
       FROM messages
       WHERE (sender_id = $1 AND recipient_id = $2) OR (sender_id = $2 AND recipient_id = $1)
       ORDER BY id ASC LIMIT 200`,
      [req.user.id, fid]
    );
    res.json(result.rows);
  }));

  return router;
};
